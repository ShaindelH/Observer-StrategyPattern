package election;

public class PopularHonest implements IPopular{
	//3) There is a completely honest strategy that reports the exact results
	
	@Override
	public String reportPopular() {
		StringBuilder report = new StringBuilder();
		report.append("REP " + getRepTotal() + " DEM " + getDemTotal());
		return report.toString();
		
	}
	
}
