package election;

public class ElectoralRepublican1 implements IElectoral {

	@Override
	public String reportElectoral() {
		StringBuilder report = new StringBuilder();
		int repElectoral = 0;
		int demElectoral = 0;
		for(int i=0; i<states.size(); i++) {
			if(states.get(i).getName() == "New York") {
				continue;
			}
			else{
				if(states.get(i).getRepVotes < states.get(i).getDemVotes()) {
					demElectoral += states.get(i).getElectoral();
				}
				else {
					repElectoral += states.get(i).getElectoral();
				}
			} 
		}
		report.append("REP" + repElectoral + " DEM " + demElectoral);
		return report.toString();
	}
	
	//1) There is a republican favoring strategy that assumes one of the states (always the same one, this should be hardcoded in) will go republican regardless of the polling data
	//2) There is a second republican favoring strategy that considers the state where the democrat has the smallest lead to be "too close to call" and splits the electoral votes giving half to the democrat and half to the republican (and in the event of an odd number it gives the extra vote to the republican of course)
	

}
