package election;

public class ElectoralHonest implements IElectoral {

	@Override
	public String reportElectoral() {
		StringBuilder report = new StringBuilder();
		
		report.append("REP " + getRepElectors() + " DEM " + getDemElectors());
		return report.toString();
	}

	
	
}
