package election;

public interface Observer {
	
	public void update(State state);

	void update(State state, Object stateReport);

}
