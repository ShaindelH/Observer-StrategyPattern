package election;

public class ElectoralDemocrat1 implements IElectoral {
	//This is a democrat favoring strategy that assumes that the state with the most electoral votes will go to the democrat regardless of polling data
	@Override
	public String reportElectoral() {
		
		StringBuilder report = new StringBuilder();
		State maxElectors = states.get(0);
		int max = maxElectors.getElectoral();
		
		for (int i = 1; i < states.size(); i++) {
			if (max < states.get(i).getElectoral()) {
				maxElectors = states.get(i);
				max = maxElectors.getElectoral();
			}
		}
		int repTotal = states.getRepElectors();
		int demTotal = states.getDemElectors();
		
		if (maxElectors.getRepVotes() > maxElectors.getDemVotes()) {
			repTotal -= maxElectors.getElectoral();
			demTotal += maxElectors.getElectoral();
		}	
		
		report.append("REP " + repTotal + " DEM " + demTotal);
		return report.toString();
	}
	
		//5) There is a completely honest strategy that reports the exact results

}
