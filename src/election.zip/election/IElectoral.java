package election;

public interface IElectoral {
	
	public String reportElectoral();
	
}
