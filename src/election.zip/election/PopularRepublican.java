package election;

public class PopularRepublican implements IPopular {
	
	@Override
	public String reportPopular(){
		
		int demTotal = 0;
		int repTotal = 0;
		for(int i=0; i<states.size(); i++) {
			demTotal += states.get(i).getDemVotes();
			repTotal += states.get(i).getRepVotes();
		}
		
		StringBuilder report = new StringBuilder();
		report.append("REP " + repTotal + " DEM " + .95 * demTotal);
		return report.toString();
		  
	}
	
	
	//1) There is a republican favoring strategy that reports 5% fewer of the democrat votes
	
	
	
}
