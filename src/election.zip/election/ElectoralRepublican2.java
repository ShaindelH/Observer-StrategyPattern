package election;

public class ElectoralRepublican2 implements IElectoral {

	@Override
	public String reportElectoral() {
		StringBuilder report = new StringBuilder();
		int tempDiff;
		State lowest = states.get(0);
		int difference = lowest.getDemVotes() - lowest.getRepVotes();
		for(int i=1; i<states.size(); i++) {
			tempDiff = states.get(i).getDemVotes() - states.get(i).getRepVotes();
			if(difference > tempDiff && tempDiff > 0) {
				lowest = states.get(i);
				difference = tempDiff;
			}
		}
		int repTotal = getRepElectors();
		int demTotal = getDemElectors() - lowest.getElectoral();

		int halfElectors = lowest.getElectoral()/2;
		repTotal += halfElectors;
		demTotal += halfElectors;
		
		if(lowest.getElectoral() % 2 == 1) {
			repTotal += 1;
		}
		report.append("REP " + repTotal + " DEM " + demTotal);
		
		return report.toString();
	}

	// 2) There is a second republican favoring strategy that considers the state
	// where the democrat has the smallest lead to be "too close to call" and splits
	// the electoral votes giving half to the democrat and half to the republican
	// (and in the event of an odd number it gives the extra vote to the republican
	// of course)

}
