package election;

public class ObserverRep extends VoteReport {

	public ObserverRep() {
		super(new PopularRepublican(), new ElectoralRepublican1());
	}

}
