package election;

import java.util.ArrayList;
import java.util.Iterator;


public abstract class StateRecords{
	
	private ArrayList <Observer> observers;
	protected ArrayList <State> states;
	
	public StateRecords() {
		observers = new ArrayList<Observer>();
		
		states = new ArrayList<State>();
		states.add(new State("New York", 29, 5000, 10000));
		states.add(new State("California", 55, 8000, 15000));
		states.add(new State("Alaska", 3, 1000, 400));
		states.add(new State("Florida", 29, 12000, 13000));
		states.add(new State("Colorado", 9, 9000, 5500));
	}
	
	public int getDemTotals() {
		int demTotal = 0;
		for(int i=0; i<states.size(); i++) {
			demTotal += states.get(i).getDemVotes();
		}
		return demTotal;
	}
	
	public int getRepTotals() {
		int repTotal = 0;
		for(int i=0; i<states.size(); i++) {
			repTotal += states.get(i).getRepVotes();
		}
		return repTotal;
	}
	
	public int getDemElectors() {
		int demElectors = 0;
		for(int i=0; i<states.size(); i++) {
			demElectors += states.get(i).getElectoral();
		}
		return demElectors;
	}
	
	public int getRepElectors() {
		int repElectors = 0;
		for(int i=0; i<states.size(); i++) {
			repElectors += states.get(i).getElectoral();
		}
		return repElectors;
	}
	
	@Override
	public void registerObserver(Observer observer) {
		if(observer != null){
			this.observers.add(observer);
		}
	}

	@Override
	public void notifyObservers() {
		Iterator<Observer> it = observers.iterator();
		while(it.hasNext()){
			Observer observer = it.next();
			observer.update(this);
		}
	}

	@Override
	public void removeObserver(Observer observer) {
		if(observer != null){
			this.observers.remove(observer);
		}
	}

}
