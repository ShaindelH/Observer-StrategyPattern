package election;

public class ElectoralDemocrat2 implements IElectoral{
	
	//This is a democrat favoring strategy that takes 2% of all republican votes in every state and makes them democrat votes instead 
	//(note that this only affects the electoral votes if there is a state within this margin)

	@Override
	public String reportElectoral() {
		
		StringBuilder report = new StringBuilder();
		
		int demTotal = 0;
		int repTotal = 0;
		
		for (int i = 0; i < states.size(); i++) {
			if (states.get(i).getDemVotes > states.get(i).getRepVotes * .98) {
				demTotal += states.get(i).getElectoral();
			}
			else {
				repTotal += states.get(i).getElectoral();
			}	
		}
		
		report.append("REP " + repTotal + " DEM " + demTotal); 
		return report.toString();
	}
	

}
