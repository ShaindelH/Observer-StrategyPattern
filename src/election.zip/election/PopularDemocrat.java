package election;

public class PopularDemocrat implements IPopular{

	@Override
	public String reportPopular() {
		//2) There is a democrat favoring strategy that simply ignores the state with the most republican votes
		State maxRep = states.get(0);
		for(int i=1; i<states.size(); i++) {
			if(states.get(i).getRepVotes > maxRep.getRepVotes()) {
				maxRep = states.get(i);
			}
		}
		
			StringBuilder report = new StringBuilder();
			report.append("REP " + getRepTotal() - maxRep.getRepVotes() + " DEM " + getDemTotal() - maxRep.getDemVotes());
			return report.toString();
			  
		}
		
	}
	
}
