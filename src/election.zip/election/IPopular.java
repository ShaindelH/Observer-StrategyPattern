package election;

public interface IPopular {
	
	public String reportPopular();

}
