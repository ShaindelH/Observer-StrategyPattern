package election;

import java.util.ArrayList;

public class VoteReport implements Observer{
	
	private IPopular iPopular;
	private IElectoral iElectoral;
	private String electoralReport;
	private String popularReport;
	private ArrayList<State> states;
	
	public VoteReport(IPopular iPopular, IElectoral iElectoral, ArrayList <State> states) {
		this.iPopular = iPopular;
		this.iElectoral = iElectoral;
		
		this.states = new ArrayList<State>();
		this.states = states;
	}
	
	public void setElectoral() {
		this.electoralReport = iElectoral.reportElectoral();
	}
	public void setPopular() {
		this.popularReport = iPopular.reportPopular();
	}
	
	public String display() {
		return ("Electoral Report: " + electoralReport 
				+ "\nPopular Report " + popularReport + "\nWe are not legally held accountable for inaccurate data");
	}

	@Override
	public void update(State state, Object updatedState) {
		
		if (updatedState instanceof StateReport) {
			
		}
		
		
	}

	
	
	
	
}
